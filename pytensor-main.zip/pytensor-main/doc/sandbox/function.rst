
.. _function:

==================
function interface
==================

WRITEME

