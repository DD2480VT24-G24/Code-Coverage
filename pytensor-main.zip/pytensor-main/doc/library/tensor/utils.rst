===================================================================
:mod:`tensor.utils` --  Tensor Utils
===================================================================

.. testsetup::

   from pytensor.tensor.utils import *

.. module:: tensor.utils
   :platform: Unix, Windows
   :synopsis: Tensor Utils
.. moduleauthor:: LISA

.. automodule:: pytensor.tensor.utils
    :members:
