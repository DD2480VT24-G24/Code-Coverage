===================================================================
:mod:`tensor.elemwise` --  Tensor Elemwise
===================================================================

.. testsetup::

   from pytensor.tensor.elemwise import *

.. module:: tensor.elemwise
   :platform: Unix, Windows
   :synopsis: Tensor Elemwise
.. moduleauthor:: LISA

.. automodule:: pytensor.tensor.elemwise
    :members:
