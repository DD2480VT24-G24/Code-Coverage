# PyTensor Code of Conduct

As a library of the PyMC project, PyTensor follows the
[PyMC code of conduct](https://github.com/pymc-devs/pymc/blob/main/CODE_OF_CONDUCT.md).
