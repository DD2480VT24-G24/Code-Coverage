# PyTensor Governance

As a library of the PyMC project, PyTensor governance and decision making
is described in the [main PyMC governance doc](https://github.com/pymc-devs/pymc/blob/main/GOVERNANCE.md)
